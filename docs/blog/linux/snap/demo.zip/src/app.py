#!/usr/bin/python

import os,sys
import subprocess

def main():
    "Run the application"

    print ('hello! this is a snap.')    

if __name__ == '__main__':
    main()